from __future__ import annotations

import hmac
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Header, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DATA = Path(os.getenv("VIDEO_DATA_DIR", "/data"))
MEDIA = DATA / "tv_media"
STATES = DATA / "channels"
LOGS = DATA / "tv_logs"
CHANNELS_FILE = DATA / "channels.json"
API_TOKEN = os.environ["VIDEO_MODULE_TOKEN"]
PUBLIC_HOST = os.getenv("VIDEO_PUBLIC_HOST", "127.0.0.1")
PUBLIC_SCHEME = os.getenv("VIDEO_PUBLIC_SCHEME", "http")
PUBLIC_PORT = int(os.getenv("VIDEO_HLS_PORT", "8888"))
MAX_FILE = 45 * 1024 * 1024

for directory in (MEDIA, STATES, LOGS):
    directory.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="AzuraCast Video TV Engine", docs_url=None, redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["X-Video-Module-Token", "Content-Type"],
)

processes: dict[str, subprocess.Popen] = {}
destination_processes: dict[str, dict] = {}
lock = threading.RLock()
live_status_lock = threading.Lock()
live_status_cache: dict[str, tuple[float, bool]] = {}


def check_token(value: str | None) -> None:
    if not value or not hmac.compare_digest(value, API_TOKEN):
        raise HTTPException(status_code=401, detail="Unauthorized")


def slug(value: str) -> str:
    value = value.lower()
    if not re.fullmatch(r"[a-z0-9_-]{1,64}", value):
        raise HTTPException(status_code=400, detail="Invalid channel shortcode")
    return value


def state_path(channel: str) -> Path:
    return STATES / f"{slug(channel)}.json"


def load_channels() -> list[dict]:
    if not CHANNELS_FILE.exists():
        return []
    try:
        channels = json.loads(CHANNELS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        raise HTTPException(status_code=500, detail="TV channel registry is unreadable")
    if not isinstance(channels, list):
        raise HTTPException(status_code=500, detail="TV channel registry is invalid")
    return channels


def save_channels(channels: list[dict]) -> None:
    tmp = CHANNELS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(channels, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CHANNELS_FILE)


def require_channel(channel: str) -> str:
    channel = slug(channel)
    if not any(item.get("id") == channel for item in load_channels()):
        raise HTTPException(status_code=404, detail="TV channel not found")
    return channel


def default_state() -> dict:
    playlist_id = uuid.uuid4().hex[:12]
    return {
        "mode": "playlist",
        "playing": False,
        "stream_key": secrets.token_urlsafe(32),
        "active_playlist_id": playlist_id,
        "playlists": [{"id": playlist_id, "name": "Videyo mwen yo", "videos": []}],
        "destinations": [],
    }


def load_state(channel: str) -> dict:
    path = state_path(channel)
    if not path.exists():
        return default_state()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        raise HTTPException(status_code=500, detail="Video playlist state is unreadable")
    if not isinstance(data.get("playlists"), list):
        raise HTTPException(status_code=500, detail="Video playlist state is invalid")
    if not isinstance(data.get("destinations", []), list):
        raise HTTPException(status_code=500, detail="Video destinations state is invalid")
    data.setdefault("destinations", [])
    return data


def save_state(channel: str, data: dict) -> None:
    path = state_path(channel)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def playlist_for(data: dict, playlist_id: str) -> dict:
    for playlist in data["playlists"]:
        if playlist["id"] == playlist_id:
            return playlist
    raise HTTPException(status_code=404, detail="Playlist not found")


def stop_process(channel: str) -> None:
    proc = processes.pop(channel, None)
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=3)


def live_stream_available(channel: str) -> bool:
    """Check whether OBS currently publishes a readable live HLS stream."""
    now = time.monotonic()
    with live_status_lock:
        cached = live_status_cache.get(channel)
        if cached and now - cached[0] < 1.5:
            return cached[1]
    url = f"http://mediamtx:8888/live/{channel}/index.m3u8"
    try:
        with urllib.request.urlopen(url, timeout=1.5) as response:
            is_available = response.status == 200
    except (urllib.error.URLError, TimeoutError, OSError):
        is_available = False
    with live_status_lock:
        live_status_cache[channel] = (time.monotonic(), is_available)
    return is_available


def keep_playlist_as_fallback(channel: str) -> bool:
    """Run the selected playlist whenever OBS is not currently on air."""
    data = load_state(channel)
    if live_stream_available(channel):
        proc = processes.get(channel)
        if proc is not None and proc.poll() is None:
            stop_process(channel)
        if data.get("playing"):
            data["playing"] = False
            save_state(channel, data)
        return True

    active = next((item for item in data["playlists"] if item["id"] == data["active_playlist_id"]), None)
    if active is None or not active["videos"]:
        return False

    proc = processes.get(channel)
    if proc is None or proc.poll() is not None:
        try:
            start_process(channel, data)
        except HTTPException:
            data["playing"] = False
            save_state(channel, data)
            return False
    return False


def start_process(channel: str, data: dict) -> None:
    stop_process(channel)
    playlist = playlist_for(data, data["active_playlist_id"])
    videos = playlist["videos"]
    if not videos:
        raise HTTPException(status_code=409, detail="Ajoute videyo nan playlist la anvan ou lanse l.")

    manifest = MEDIA / channel / playlist["id"] / "playlist.ffconcat"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    lines = ["ffconcat version 1.0"]
    for video in videos:
        path = (manifest.parent / video["disk_name"]).resolve()
        if not path.is_file() or not path.is_relative_to(MEDIA.resolve()):
            raise HTTPException(status_code=409, detail="Yon fichye nan playlist la manke.")
        lines.append("file '" + str(path).replace("'", "'\\''") + "'")
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")

    publish_url = f"rtmp://mediamtx:1935/auto/{channel}?user=broadcaster&pass={data['stream_key']}"
    log_file = open(LOGS / f"{channel}.log", "ab", buffering=0)
    command = [
        "ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "warning", "-re",
        "-stream_loop", "-1", "-f", "concat", "-safe", "0", "-i", str(manifest),
        # Each normalized file is individually playable, but stream-copying a
        # looping concat manifest can reset DTS at file/playlist boundaries.
        # Re-encode the continuous output so MediaMTX receives monotonic H.264/AAC.
        "-map", "0:v:0", "-map", "0:a:0",
        # Rebase both timelines across every concat boundary; some source
        # files carry start offsets that otherwise leave MediaMTX with a long
        # HLS gap or a black frame while waiting for the next segment.
        "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,setpts=N/(30*TB),fps=30,format=yuv420p",
        "-c:v", "libx264", "-preset", "veryfast",
        "-tune", "zerolatency", "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
        "-force_key_frames", "expr:gte(t,n_forced*2)",
        "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
        "-af", "asetpts=N/SR/TB,aresample=async=1:first_pts=0", "-f", "flv", publish_url,
    ]
    try:
        processes[channel] = subprocess.Popen(
            command, stdin=subprocess.DEVNULL, stdout=log_file, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    except OSError as exc:
        log_file.close()
        raise HTTPException(status_code=500, detail=f"Pa kapab kòmanse difizyon an: {exc}")
    log_file.close()
    data["mode"] = "playlist"
    data["playing"] = True
    save_state(channel, data)


def destination_key(channel: str, destination_id: str) -> str:
    return f"{channel}:{destination_id}"


def stop_destination_process(key: str) -> None:
    worker = destination_processes.get(key)
    if not worker:
        return
    proc = worker.get("process")
    if proc is not None and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=3)
    worker["process"] = None
    worker["source"] = None


def destination_source(channel: str, data: dict, destination: dict, live_active: bool) -> str | None:
    source_mode = destination.get("source_mode", "program")
    playlist_process = processes.get(channel)
    playlist_active = playlist_process is not None and playlist_process.poll() is None
    if source_mode == "live":
        return f"live/{channel}" if live_active else None
    if source_mode == "playlist":
        return f"auto/{channel}" if playlist_active and not live_active else None
    if live_active:
        return f"live/{channel}"
    return f"auto/{channel}" if playlist_active else None


def destination_output_url(destination: dict) -> str:
    base = urllib.parse.urlsplit(destination["server_url"])
    # Keep ':' intact: Telegram RTMPS stream keys use it as a literal delimiter.
    key = urllib.parse.quote(str(destination["stream_key"]), safe=":")
    path = base.path.rstrip("/") + "/" + key
    return urllib.parse.urlunsplit((base.scheme, base.netloc, path, base.query, ""))


def maintain_destination_processes(channel: str, data: dict, live_active: bool) -> None:
    configured_ids = set()
    for destination in data.get("destinations", []):
        destination_id = str(destination.get("id", ""))
        if not destination_id:
            continue
        key = destination_key(channel, destination_id)
        configured_ids.add(key)
        worker = destination_processes.setdefault(key, {"process": None, "source": None, "last_attempt": 0.0})
        desired_source = destination_source(channel, data, destination, live_active) if destination.get("enabled") else None
        proc = worker.get("process")
        if proc is not None and proc.poll() is not None:
            worker["process"] = None
            proc = None
        if proc is not None and worker.get("source") != desired_source:
            stop_destination_process(key)
            proc = None
        if desired_source is None:
            if proc is not None:
                stop_destination_process(key)
            continue
        if proc is not None:
            continue
        now = time.monotonic()
        if now - float(worker.get("last_attempt", 0.0)) < 8:
            continue
        worker["last_attempt"] = now
        input_url = f"rtmp://mediamtx:1935/{desired_source}"
        output_url = destination_output_url(destination)
        log_path = LOGS / f"destination-{channel}-{destination_id}.log"
        log_file = open(log_path, "ab", buffering=0)
        command = [
            "ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "warning",
            "-rw_timeout", "15000000", "-i", input_url,
            "-map", "0:v:0", "-map", "0:a?", "-c", "copy", "-f", "flv", output_url,
        ]
        try:
            worker["process"] = subprocess.Popen(
                command, stdin=subprocess.DEVNULL, stdout=log_file, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            worker["source"] = desired_source
        except OSError:
            worker["process"] = None
            worker["source"] = None
        finally:
            log_file.close()

    for key in tuple(destination_processes):
        if key.startswith(f"{channel}:") and key not in configured_ids:
            stop_destination_process(key)
            destination_processes.pop(key, None)


def destination_response(channel: str, destination: dict) -> dict:
    key = destination_key(channel, str(destination.get("id", "")))
    worker = destination_processes.get(key, {})
    proc = worker.get("process")
    running = proc is not None and proc.poll() is None
    if not destination.get("enabled"):
        status = "stopped"
    elif running:
        status = "sending"
    else:
        status = "waiting" if worker.get("last_attempt", 0.0) == 0 else "reconnecting"
    source = worker.get("source") if running else None
    return {
        "id": destination.get("id"),
        "name": destination.get("name", ""),
        "platform": destination.get("platform", "custom"),
        "server_url": destination.get("server_url", ""),
        "source_mode": destination.get("source_mode", "program"),
        "stream_key_configured": bool(destination.get("stream_key")),
        "enabled": bool(destination.get("enabled")),
        "status": status,
        "active_source": "live" if source and source.startswith("live/") else "playlist" if source else None,
    }


class PlaylistCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class TvChannelCreate(BaseModel):
    id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=80)


class TvChannelUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ModeUpdate(BaseModel):
    mode: str


class OrderUpdate(BaseModel):
    video_ids: list[str]


class DestinationCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    platform: str = Field(default="custom", max_length=20)
    server_url: str = Field(min_length=10, max_length=1024)
    stream_key: str = Field(min_length=1, max_length=512)
    source_mode: str = Field(default="program", max_length=20)
    enabled: bool = False


class DestinationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=80)
    platform: str | None = Field(default=None, max_length=20)
    server_url: str | None = Field(default=None, min_length=10, max_length=1024)
    stream_key: str | None = Field(default=None, max_length=512)
    source_mode: str | None = Field(default=None, max_length=20)
    enabled: bool | None = None


def validate_destination_fields(platform: str, server_url: str, source_mode: str) -> str:
    if platform not in {"youtube", "facebook", "twitch", "kick", "custom"}:
        raise HTTPException(status_code=400, detail="Chwazi yon platfòm difizyon ki sipòte oswa lòt RTMP.")
    if source_mode not in {"program", "live", "playlist"}:
        raise HTTPException(status_code=400, detail="Sous difizyon an pa valab.")
    try:
        parsed = urllib.parse.urlsplit(server_url.strip())
        hostname = parsed.hostname
        parsed.port
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Mete yon URL sèvè RTMP oswa RTMPS valab san kle difizyon an.") from exc
    if parsed.scheme not in {"rtmp", "rtmps"} or not hostname or parsed.username or parsed.password or parsed.fragment:
        raise HTTPException(status_code=400, detail="Mete yon URL sèvè RTMP oswa RTMPS valab san kle difizyon an.")
    if hostname.lower().rstrip(".") in {"localhost", "mediamtx", "video-engine"}:
        raise HTTPException(status_code=400, detail="URL sa a pa kapab retounen sou sèvis TV entèn lan.")
    try:
        addresses = {ipaddress.ip_address(hostname)}
    except ValueError:
        try:
            addresses = {ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(hostname, parsed.port)}
        except (OSError, ValueError) as exc:
            raise HTTPException(status_code=400, detail="Pa kapab jwenn adrès IP destinasyon sa a.") from exc
    if not addresses or any(not address.is_global for address in addresses):
        raise HTTPException(status_code=400, detail="Destinasyon an dwe itilize yon adrès IP piblik.")
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path.rstrip("/"), parsed.query, ""))


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/auth")
async def mediamtx_auth(payload: dict):
    action = str(payload.get("action", ""))
    path = str(payload.get("path", ""))
    match = re.fullmatch(r"(?:auto|live)/([a-z0-9_-]{1,64})", path)
    if not match:
        raise HTTPException(status_code=401, detail="Unauthorized")
    channel = match.group(1)
    if not any(item.get("id") == channel for item in load_channels()):
        raise HTTPException(status_code=401, detail="Unauthorized")
    if action in {"read", "playback"}:
        return {"ok": True}
    if action == "publish":
        data = load_state(channel)
        user = str(payload.get("user", ""))
        password = str(payload.get("password", ""))
        if user == "broadcaster" and hmac.compare_digest(password, str(data.get("stream_key", ""))):
            return {"ok": True}
    raise HTTPException(status_code=401, detail="Unauthorized")


@app.get("/api/channels")
def list_channels(x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    result = []
    with lock:
        for item in load_channels():
            channel = slug(str(item.get("id", "")))
            data = load_state(channel)
            if not state_path(channel).exists():
                save_state(channel, data)
            proc = processes.get(channel)
            running = proc is not None and proc.poll() is None
            live_active = live_stream_available(channel)
            active = next((p for p in data["playlists"] if p["id"] == data["active_playlist_id"]), {})
            result.append({
                "id": channel,
                "name": str(item.get("name", channel)),
                "mode": "live" if live_active else "playlist",
                "engine_running": running,
                "live_active": live_active,
                "video_count": sum(len(p.get("videos", [])) for p in data["playlists"]),
                "active_video_count": len(active.get("videos", [])),
            })
    return result


@app.post("/api/channels")
def create_channel(body: TvChannelCreate, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = slug(body.id)
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Mete non chanèl la.")
    with lock:
        channels = load_channels()
        if any(item.get("id") == channel for item in channels):
            raise HTTPException(status_code=409, detail="Gen yon chanèl TV ki deja sèvi ak URL sa a.")
        record = {"id": channel, "name": name}
        channels.append(record)
        save_channels(channels)
        save_state(channel, default_state())
        return {**record, "mode": "playlist", "engine_running": False, "video_count": 0, "active_video_count": 0}


@app.patch("/api/channels/{channel}")
def update_channel(channel: str, body: TvChannelUpdate, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Mete non chanèl la.")
    with lock:
        channels = load_channels()
        record = next(item for item in channels if item.get("id") == channel)
        record["name"] = name
        save_channels(channels)
    return {"id": channel, "name": name}


@app.delete("/api/channels/{channel}")
def delete_channel(channel: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        stop_process(channel)
        for key in tuple(destination_processes):
            if key.startswith(f"{channel}:"):
                stop_destination_process(key)
                destination_processes.pop(key, None)
        save_channels([item for item in load_channels() if item.get("id") != channel])
        state_path(channel).unlink(missing_ok=True)
        shutil.rmtree(MEDIA / channel, ignore_errors=True)
        (LOGS / f"{channel}.log").unlink(missing_ok=True)
    return {"success": True}


@app.get("/api/{channel}")
def get_channel(channel: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    channel_record = next(item for item in load_channels() if item.get("id") == channel)
    with lock:
        data = load_state(channel)
        if not state_path(channel).exists():
            save_state(channel, data)
        proc = processes.get(channel)
        alive = proc is not None and proc.poll() is None
        live_active = live_stream_available(channel)
        data["playing"] = live_active or alive
        return {
            **data,
            "mode": "live" if live_active else "playlist",
                "live_active": live_active,
            "channel": channel,
            "channel_name": str(channel_record.get("name", channel)),
            "stream_key": data["stream_key"],
            "rtmp_url": f"rtmp://{PUBLIC_HOST}:1935/live",
            "live_stream_key": f"{channel}?user=broadcaster&pass={data['stream_key']}",
            "playlist_hls_url": f"{PUBLIC_SCHEME}://{PUBLIC_HOST}:{PUBLIC_PORT}/auto/{channel}/index.m3u8",
            "live_hls_url": f"{PUBLIC_SCHEME}://{PUBLIC_HOST}:{PUBLIC_PORT}/live/{channel}/index.m3u8",
            "destinations": [destination_response(channel, destination) for destination in data.get("destinations", [])],
            "engine_running": alive,
            "live_active": live_active,
        }


@app.post("/api/{channel}/destinations")
def create_destination(
    channel: str,
    body: DestinationCreate,
    x_video_module_token: str | None = Header(default=None),
):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    name = body.name.strip()
    stream_key = body.stream_key.strip()
    if not name or not stream_key:
        raise HTTPException(status_code=400, detail="Mete non destinasyon an ak kle difizyon an.")
    server_url = validate_destination_fields(body.platform, body.server_url, body.source_mode)
    with lock:
        data = load_state(channel)
        if len(data["destinations"]) >= 10:
            raise HTTPException(status_code=409, detail="Ou ka mete jiska 10 destinasyon pou chak chanèl.")
        destination = {
            "id": uuid.uuid4().hex[:12],
            "name": name,
            "platform": body.platform,
            "server_url": server_url,
            "stream_key": stream_key,
            "source_mode": body.source_mode,
            "enabled": body.enabled,
        }
        data["destinations"].append(destination)
        save_state(channel, data)
        return destination_response(channel, destination)


@app.patch("/api/{channel}/destinations/{destination_id}")
def update_destination(
    channel: str,
    destination_id: str,
    body: DestinationUpdate,
    x_video_module_token: str | None = Header(default=None),
):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        destination = next((item for item in data["destinations"] if item.get("id") == destination_id), None)
        if destination is None:
            raise HTTPException(status_code=404, detail="Destinasyon an pa egziste.")
        update = body.model_dump(exclude_unset=True)
        platform = update.get("platform", destination["platform"])
        server_url = update.get("server_url", destination["server_url"])
        source_mode = update.get("source_mode", destination.get("source_mode", "program"))
        destination["server_url"] = validate_destination_fields(platform, server_url, source_mode)
        destination["platform"] = platform
        destination["source_mode"] = source_mode
        if "name" in update:
            name = (update["name"] or "").strip()
            if not name:
                raise HTTPException(status_code=400, detail="Mete non destinasyon an.")
            destination["name"] = name
        new_stream_key = update.get("stream_key")
        if new_stream_key is not None and new_stream_key.strip():
            destination["stream_key"] = new_stream_key.strip()
        if update.get("enabled") is not None:
            destination["enabled"] = update["enabled"]
        stop_destination_process(destination_key(channel, destination_id))
        save_state(channel, data)
        return destination_response(channel, destination)


@app.delete("/api/{channel}/destinations/{destination_id}")
def delete_destination(
    channel: str,
    destination_id: str,
    x_video_module_token: str | None = Header(default=None),
):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        if not any(item.get("id") == destination_id for item in data["destinations"]):
            raise HTTPException(status_code=404, detail="Destinasyon an pa egziste.")
        key = destination_key(channel, destination_id)
        stop_destination_process(key)
        destination_processes.pop(key, None)
        data["destinations"] = [item for item in data["destinations"] if item.get("id") != destination_id]
        save_state(channel, data)
    return {"success": True}


@app.get("/api/{channel}/public-status")
def public_status(channel: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    data = load_state(channel)
    live_active = live_stream_available(channel)
    active = next((item for item in data["playlists"] if item["id"] == data["active_playlist_id"]), None)
    has_playlist = bool(active and active["videos"])
    mode = "live" if live_active else "playlist"
    stream_url = (
        f"{PUBLIC_SCHEME}://{PUBLIC_HOST}:{PUBLIC_PORT}/live/{channel}/index.m3u8"
        if live_active else
        f"{PUBLIC_SCHEME}://{PUBLIC_HOST}:{PUBLIC_PORT}/auto/{channel}/index.m3u8" if has_playlist else ""
    )
    return {
        "channel": channel,
        "mode": mode,
        "live_active": live_active,
        "stream_available": live_active or has_playlist,
        "stream_url": stream_url,
    }


@app.get("/api/{channel}/logs")
def channel_logs(
    channel: str,
    lines: int = Query(default=100, ge=10, le=500),
    x_video_module_token: str | None = Header(default=None),
):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    path = LOGS / f"{channel}.log"
    if not path.is_file():
        return {"lines": []}
    try:
        content = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        raise HTTPException(status_code=500, detail="Pa kapab li log difizyon an.") from exc
    return {"lines": content[-lines:]}


@app.post("/api/{channel}/playlists")
def create_playlist(channel: str, body: PlaylistCreate, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        item = {"id": uuid.uuid4().hex[:12], "name": body.name.strip(), "videos": []}
        data["playlists"].append(item)
        save_state(channel, data)
        return item


@app.delete("/api/{channel}/playlists/{playlist_id}")
def delete_playlist(channel: str, playlist_id: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        if len(data["playlists"]) < 2:
            raise HTTPException(status_code=409, detail="Kenbe omwen yon playlist videyo.")
        if not any(p["id"] == playlist_id for p in data["playlists"]):
            raise HTTPException(status_code=404, detail="Playlist not found")
        if data["active_playlist_id"] == playlist_id:
            stop_process(channel)
            data["playing"] = False
        data["playlists"] = [p for p in data["playlists"] if p["id"] != playlist_id]
        if data["active_playlist_id"] == playlist_id:
            data["active_playlist_id"] = data["playlists"][0]["id"]
        shutil.rmtree(MEDIA / channel / playlist_id, ignore_errors=True)
        save_state(channel, data)
        return {"success": True}


@app.post("/api/{channel}/playlists/{playlist_id}/select")
def select_playlist(channel: str, playlist_id: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        playlist_for(data, playlist_id)
        was_playing = data["playing"] and data["mode"] == "playlist"
        stop_process(channel)
        data["active_playlist_id"] = playlist_id
        data["playing"] = False
        save_state(channel, data)
        if was_playing:
            start_process(channel, data)
        return {"success": True, "active_playlist_id": playlist_id}


@app.post("/api/{channel}/playlists/{playlist_id}/order")
def reorder_videos(channel: str, playlist_id: str, body: OrderUpdate, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        playlist = playlist_for(data, playlist_id)
        current_ids = [item["id"] for item in playlist["videos"]]
        if len(body.video_ids) != len(current_ids) or set(body.video_ids) != set(current_ids):
            raise HTTPException(status_code=400, detail="Lòd videyo a pa valab.")
        was_playing = data.get("playing") and data.get("active_playlist_id") == playlist_id and data.get("mode") == "playlist"
        items = {item["id"]: item for item in playlist["videos"]}
        playlist["videos"] = [items[item_id] for item_id in body.video_ids]
        save_state(channel, data)
        if was_playing:
            start_process(channel, data)
        return {"success": True}


@app.post("/api/{channel}/playlists/{playlist_id}/videos")
async def upload_video(
    channel: str, playlist_id: str, file: UploadFile = File(...),
    x_video_module_token: str | None = Header(default=None),
):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi", ".flv", ".mpeg", ".mpg", ".wmv", ".3gp", ".ts", ".mts", ".m2ts", ".ogv"}:
        raise HTTPException(status_code=400, detail="Fòma sa a pa sipòte. Sèvi ak MP4, MOV, MKV, WebM, AVI, FLV, MPEG, WMV oswa 3GP.")

    video_id = uuid.uuid4().hex
    upload_name = video_id + ".source" + suffix
    disk_name = video_id + ".mp4"
    with lock:
        data = load_state(channel)
        playlist = playlist_for(data, playlist_id)
        folder = MEDIA / channel / playlist_id
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / upload_name
        normalized_target = folder / disk_name
        size = 0
        state_saved = False
        try:
            with target.open("wb") as output:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_FILE:
                        raise HTTPException(status_code=413, detail="Limit fichye a se 45 MB sou sèvè sa a.")
                    output.write(chunk)
            probe = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "json", str(target)],
                capture_output=True, text=True, timeout=30, check=True,
            )
            streams = json.loads(probe.stdout).get("streams", [])
            video = next((s for s in streams if s.get("codec_type") == "video"), None)
            audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
            if not video:
                raise HTTPException(status_code=400, detail="Fichye a pa gen okenn tras videyo lizib.")

            command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", str(target)]
            if not audio:
                command.extend(["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100"])
            command.extend([
                "-map", "0:v:0", "-map", "0:a:0" if audio else "1:a:0",
                "-vf", "scale=1280:720:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30",
                "-af", "aresample=async=1:first_pts=0",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                "-profile:v", "main", "-level:v", "3.1", "-pix_fmt", "yuv420p",
                "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
                "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
                "-map_metadata", "-1", "-movflags", "+faststart",
            ])
            if not audio:
                command.append("-shortest")
            command.append(str(normalized_target))
            subprocess.run(command, capture_output=True, text=True, timeout=180, check=True)

            normalized_probe = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,pix_fmt,avg_frame_rate,sample_rate,channels,profile:format=duration", "-of", "json", str(normalized_target)],
                capture_output=True, text=True, timeout=30, check=True,
            )
            normalized = json.loads(normalized_probe.stdout)
            video = next((s for s in normalized.get("streams", []) if s.get("codec_type") == "video"), None)
            audio = next((s for s in normalized.get("streams", []) if s.get("codec_type") == "audio"), None)
            if not video or not audio:
                raise HTTPException(status_code=400, detail="Sèvè a pa t ka konvèti videyo sa a pou difizyon.")
            raw_duration = (normalized.get("format") or {}).get("duration")
            duration = float(raw_duration) if raw_duration not in (None, "N/A") else None
            item = {
                "id": video_id, "name": Path(file.filename or disk_name).name[:180],
                "disk_name": disk_name, "bytes": normalized_target.stat().st_size, "width": int(video["width"]),
                "height": int(video["height"]), "pix_fmt": video.get("pix_fmt"),
                "frame_rate": video.get("avg_frame_rate"), "profile": video.get("profile"),
                "audio_sample_rate": audio.get("sample_rate"), "audio_channels": audio.get("channels"),
                "duration": duration,
            }
            playlist["videos"].append(item)
            save_state(channel, data)
            state_saved = True
            target.unlink(missing_ok=True)
            if data.get("playing") and data.get("active_playlist_id") == playlist_id and data.get("mode") == "playlist":
                start_process(channel, data)
            return item
        except HTTPException:
            target.unlink(missing_ok=True)
            if not state_saved:
                normalized_target.unlink(missing_ok=True)
            raise
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError, ValueError) as exc:
            target.unlink(missing_ok=True)
            if not state_saved:
                normalized_target.unlink(missing_ok=True)
            print(f"Video upload conversion failed ({type(exc).__name__}): {exc}", flush=True)
            if isinstance(exc, subprocess.CalledProcessError) and exc.stderr:
                print(str(exc.stderr)[-1200:], flush=True)
            raise HTTPException(status_code=400, detail="Fichye videyo a pa lizib oswa li pa ka konvèti pou difizyon.")
        finally:
            await file.close()


@app.delete("/api/{channel}/playlists/{playlist_id}/videos/{video_id}")
def delete_video(channel: str, playlist_id: str, video_id: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        playlist = playlist_for(data, playlist_id)
        item = next((v for v in playlist["videos"] if v["id"] == video_id), None)
        if item is None:
            raise HTTPException(status_code=404, detail="Video not found")
        was_playing = data["playing"] and data["active_playlist_id"] == playlist_id
        if was_playing:
            stop_process(channel)
        playlist["videos"] = [v for v in playlist["videos"] if v["id"] != video_id]
        (MEDIA / channel / playlist_id / item["disk_name"]).unlink(missing_ok=True)
        data["playing"] = False
        save_state(channel, data)
        if was_playing and playlist["videos"]:
            start_process(channel, data)
        return {"success": True}


@app.post("/api/{channel}/mode")
def set_mode(channel: str, body: ModeUpdate, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    if body.mode not in {"playlist", "live"}:
        raise HTTPException(status_code=400, detail="Mode videyo a pa valab.")
    with lock:
        data = load_state(channel)
        stop_process(channel)
        data["mode"] = body.mode
        data["playing"] = False
        save_state(channel, data)
        return {"success": True, "mode": body.mode}


@app.post("/api/{channel}/start")
def start_channel(channel: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        data = load_state(channel)
        if data["mode"] != "playlist":
            raise HTTPException(status_code=409, detail="Mete chanèl TV a sou mòd playlist pou jwe videyo yo otomatikman.")
        start_process(channel, data)
        return {"success": True, "playing": True}


@app.post("/api/{channel}/stop")
def stop_channel(channel: str, x_video_module_token: str | None = Header(default=None)):
    check_token(x_video_module_token)
    channel = require_channel(channel)
    with lock:
        stop_process(channel)
        data = load_state(channel)
        data["playing"] = False
        save_state(channel, data)
        return {"success": True, "playing": False}


def recover_playlists() -> None:
    while True:
        time.sleep(2)
        with lock:
            for item in load_channels():
                channel = str(item.get("id", ""))
                try:
                    live_active = keep_playlist_as_fallback(channel)
                    maintain_destination_processes(channel, load_state(channel), live_active)
                except Exception:
                    continue


threading.Thread(target=recover_playlists, daemon=True).start()
