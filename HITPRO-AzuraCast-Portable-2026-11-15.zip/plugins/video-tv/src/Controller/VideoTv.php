<?php

declare(strict_types=1);

namespace Plugin\VideoTv\Controller;

use App\Controller\SingleActionInterface;
use App\Http\Response;
use App\Http\ServerRequest;
use Psr\Http\Message\ResponseInterface;
use Throwable;

final class VideoTv implements SingleActionInterface
{
    public function __invoke(ServerRequest $request, Response $response, array $params): ResponseInterface
    {
        if ($request->getMethod() === 'GET' && isset($params['channel'])) {
            $channel = strtolower((string)$params['channel']);
            if (!preg_match('/^[a-z0-9_-]{1,64}$/', $channel)) {
                return $response->withStatus(400)->withJson(['detail' => 'Non chanèl la pa valab.']);
            }
            if ($request->getUri()->getPath() === '/video-tv/status/' . $channel) {
                try {
                    $engineResponse = $this->requestEngine(
                        'GET',
                        rtrim((string)getenv('VIDEO_ENGINE_URL'), '/') . '/api/' . rawurlencode($channel) . '/public-status',
                        headers: ['X-Video-Module-Token: ' . (string)getenv('VIDEO_MODULE_TOKEN')],
                        timeout: 5
                    );
                    if ($engineResponse['status'] >= 400) {
                        throw new \RuntimeException('Video engine returned HTTP ' . $engineResponse['status']);
                    }
                    $output = $response->getBody();
                    $output->write($engineResponse['body']);
                    return $response->withStatus(200)
                        ->withHeader('Content-Type', 'application/json; charset=utf-8')
                        ->withHeader('Cache-Control', 'no-store, max-age=0')
                        ->withBody($output);
                } catch (Throwable $e) {
                    return $response->withStatus(503)->withJson(['detail' => 'Channel status is temporarily unavailable.'])
                        ->withHeader('Cache-Control', 'no-store, max-age=0');
                }
            }
            if ($request->getUri()->getPath() === '/video-tv/watch/' . $channel) {
                try {
                    $engineResponse = $this->requestEngine(
                        'GET',
                        rtrim((string)getenv('VIDEO_ENGINE_URL'), '/') . '/api/' . rawurlencode($channel),
                        headers: ['X-Video-Module-Token: ' . (string)getenv('VIDEO_MODULE_TOKEN')],
                        timeout: 10
                    );
                    if ($engineResponse['status'] >= 400) {
                        throw new \RuntimeException('Video engine returned HTTP ' . $engineResponse['status']);
                    }
                    $data = json_decode($engineResponse['body'], true, 512, JSON_THROW_ON_ERROR);
                    $streamUrl = ($data['mode'] ?? '') === 'live' ? $data['live_hls_url'] : $data['playlist_hls_url'];
                    return $request->getView()->renderToResponse($response, 'video_tv::watch', [
                        'channelName' => (string)($data['channel_name'] ?? $channel),
                        'streamUrl' => $streamUrl,
                        'statusUrl' => '/video-tv/status/' . rawurlencode($channel),
                        'mode' => (string)($data['mode'] ?? 'playlist'),
                    ]);
                } catch (Throwable $e) {
                    error_log('[Video TV] Public watch render failed: ' . $e::class . ': ' . $e->getMessage());
                    return $response->withStatus(503)->withJson(['detail' => 'Difizyon videyo a poko pare.']);
                }
            }
        }

        $path = trim((string)($params['path'] ?? ''), '/');
        if ($path === '') {
            return $response->withStatus(404)->withJson(['detail' => 'Chemen API a pa valab.']);
        }
        $target = rtrim((string)getenv('VIDEO_ENGINE_URL'), '/') . '/api/'
            . implode('/', array_map('rawurlencode', explode('/', $path)));

        try {
            $headers = [
                'Accept: application/json',
                'X-Video-Module-Token: ' . (string)getenv('VIDEO_MODULE_TOKEN'),
            ];
            $body = null;

            if (in_array($request->getMethod(), ['POST', 'PATCH', 'PUT'], true)) {
                $uploads = $request->getUploadedFiles();
                $uploaded = $request->getMethod() === 'POST' ? ($uploads['file'] ?? null) : null;
                if ($uploaded !== null && $uploaded->getError() === UPLOAD_ERR_OK) {
                    $stream = $uploaded->getStream();
                    $tmpPath = $stream->getMetadata('uri');
                    if (!is_string($tmpPath) || !is_file($tmpPath)) {
                        throw new \RuntimeException('Pa kapab li fichye telechaje a.');
                    }
                    $body = [
                        'file' => new \CURLFile(
                            $tmpPath,
                            $uploaded->getClientMediaType() ?: 'application/octet-stream',
                            $uploaded->getClientFilename() ?: 'video.mp4'
                        ),
                    ];
                } else {
                    $body = $request->getParsedBody();
                    $body = json_encode(is_array($body) ? $body : [], JSON_THROW_ON_ERROR);
                    $headers[] = 'Content-Type: application/json';
                }
            }

            $engineResponse = $this->requestEngine($request->getMethod(), $target, $body, $headers);
            $output = $response->getBody();
            $output->write($engineResponse['body']);
            return $response->withStatus($engineResponse['status'])
                ->withHeader('Content-Type', 'application/json; charset=utf-8')
                ->withBody($output);
        } catch (Throwable $e) {
            return $response->withStatus(502)->withJson([
                'detail' => 'Sèvis Video TV la pa reponn. Verifye si sèvis la ap fonksyone.',
            ]);
        }
    }

    /** @return array{status: int, body: string} */
    private function requestEngine(
        string $method,
        string $url,
        mixed $body = null,
        array $headers = [],
        int $timeout = 1800
    ): array {
        $handle = curl_init($url);
        if ($handle === false) {
            throw new \RuntimeException('Unable to initialize cURL.');
        }

        $options = [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => $headers,
        ];
        if ($body !== null) {
            $options[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($handle, $options);
        $payload = curl_exec($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = curl_error($handle);
        curl_close($handle);

        if ($payload === false) {
            throw new \RuntimeException('Video engine request failed: ' . $error);
        }

        return ['status' => $status, 'body' => $payload];
    }
}
