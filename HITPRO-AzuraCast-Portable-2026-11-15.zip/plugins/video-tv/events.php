<?php

declare(strict_types=1);

use App\CallableEventDispatcherInterface;
use App\Event;
use App\Middleware;
use App\Enums\GlobalPermissions;
use Plugin\VideoTv\Controller\VideoTv;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

require_once __DIR__ . '/src/Controller/VideoTv.php';

return static function (CallableEventDispatcherInterface $dispatcher): void {
    $dispatcher->addListener(Event\BuildView::class, static function (Event\BuildView $event): void {
        $event->getView()->addFolder('video_tv', __DIR__ . '/templates');
    });

    $dispatcher->addListener(Event\BuildRoutes::class, static function (Event\BuildRoutes $event): void {
        $app = $event->getApp();
        $invoke = function (ServerRequestInterface $request, ResponseInterface $response, array $params): ResponseInterface {
            return (new VideoTv())($request, $response, $params);
        };
        $watchRoute = $app->get('/video-tv/watch/{channel}', $invoke)
            ->setName('video-tv:watch')
            ->add(Middleware\EnableView::class);
        $app->get('/video-tv/status/{channel}', $invoke)->setName('video-tv:status');
        $legacyTvRedirect = function (
            ServerRequestInterface $request,
            ResponseInterface $response,
            array $params = []
        ): ResponseInterface {
            $path = trim((string)($params['routes'] ?? ''), '/');
            $target = '/admin/tv' . ($path !== '' ? '/' . $path : '');
            return $response->withHeader('Location', $target)->withStatus(302);
        };
        $app->get('/tv', $legacyTvRedirect)->setName('tv:legacy_redirect');
        $app->get('/tv/{routes:.+}', $legacyTvRedirect);
        $tvRoutes = $app->group('/plugin/video-tv/api', function ($group) use ($invoke): void {
            $group->map(['GET', 'POST', 'PATCH', 'DELETE'], '/{path:.*}', $invoke)
                ->setName('video-tv:api:action');
        });
        $tvRoutes->add(new Middleware\Permissions(GlobalPermissions::Stations));
        $tvRoutes->add(Middleware\RequireLogin::class);
        $tvRoutes->add(Middleware\Auth\StandardAuth::class);
        $tvRoutes->add(Middleware\InjectSession::class);
    });
};
