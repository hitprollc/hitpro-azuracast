# AzuraCast Video TV module

This plugin adds a global **TV Channels** area to AzuraCast. TV channels are independent of radio stations: each has its own playlists, video files, RTMP stream key for compatible live encoders, playback mode, and public watch page.

## AzuraCast integration

- The dashboard exposes a top-level TV Channels branch, separate from station management.
- Access is managed through AzuraCast administration login and the global view-administration permission.
- Create and manage channels at `/admin/tv`; manage a channel at `/admin/tv/{channel}`. The legacy `/tv` path redirects to `/admin/tv`.
- Public playback pages use `/video-tv/watch/{channel}`.
- The protected plugin API is rooted at `/plugin/video-tv/api`. Channel settings, playlists, encoder logs and public playback are managed from the TV channel sidebar.

## Video engine API

The engine stores its channel registry in `/data/channels.json`, playlist state in `/data/channels`, and media/log files under `/data/tv_media` and `/data/tv_logs`. These paths are separate from the legacy station-oriented paths, which are left untouched.

The engine supports channel creation/deletion, playlist management, automatic normalization of uploaded videos to a shared 720p H.264/AAC format, RTMP publishing from compatible video encoders (including OBS), and HLS playback. This allows a playlist to contain videos with different resolutions, pixel formats, and input codecs. Configurable RTMP/RTMPS destinations can relay the current program, live input, or scheduled playlist to YouTube Live, Facebook Live, Twitch, Kick, and other RTMP-compatible services. Destination server URLs and stream keys are supplied by the channel administrator; no platform API integration is used. The public watch page is accessible without signing in; management requires an authenticated AzuraCast administration session.

## Deploy/update

Mount this directory at `/var/azuracast/plugins/video-tv`, build/restart the video engine image after changing `engine/app.py`, and restart the AzuraCast web container after changing plugin PHP or dashboard assets. Persist `/data` for the video engine.
