<?php

declare(strict_types=1);

namespace Plugin\DirectAudioImport\Controller;

use App\Controller\SingleActionInterface;
use App\Http\Response;
use App\Http\ServerRequest;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Component\Mime\Part\DataPart;
use Symfony\Component\Mime\Part\Multipart\FormDataPart;
use Throwable;

final class ImportAudio implements SingleActionInterface
{
    private const MAX_BYTES = 104857600;
    private const ALLOWED_EXTENSIONS = ['mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'flac', 'wav', 'aiff'];

    public function __invoke(ServerRequest $request, Response $response, array $params): ResponseInterface
    {
        if ($request->getMethod() === 'GET') {
            return $request->getView()->renderToResponse($response, 'direct_audio_import::import');
        }

        $body = $request->getParsedBody();
        $apiKey = trim((string)$request->getHeaderLine('X-API-Key'));
        if (!is_array($body) || $apiKey === '' || strlen($apiKey) > 256) {
            return $response->withStatus(400)->withJson(['success' => false, 'message' => 'Mete yon API key AzuraCast valab.']);
        }

        $url = trim((string)($body['url'] ?? ''));
        $stationId = filter_var($body['station_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $playlistId = filter_var($body['playlist_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($url === '' || $stationId === false || $playlistId === false) {
            return $response->withStatus(400)->withJson(['success' => false, 'message' => 'Chwazi estasyon ak playlist, epi mete yon lyen odyo dirèk.']);
        }

        $tmpFile = null;
        try {
            $client = HttpClient::create(['max_redirects' => 0, 'timeout' => 30]);
            $apiBase = (string)$request->getUri()->getScheme() . '://' . (string)$request->getUri()->getAuthority();
            $playlistsResponse = $client->request('GET', $apiBase . '/api/station/' . $stationId . '/playlists', [
                'headers' => ['X-API-Key' => $apiKey, 'Accept' => 'application/json'],
            ]);
            $playlistsStatus = $playlistsResponse->getStatusCode();
            if ($playlistsStatus < 200 || $playlistsStatus >= 300) {
                throw new \RuntimeException('API key la pa gen aksè sou estasyon sa a.');
            }
            $playlistData = json_decode($playlistsResponse->getContent(false), true);
            $playlistRows = is_array($playlistData)
                ? ($playlistData['rows'] ?? $playlistData['items'] ?? $playlistData['data'] ?? $playlistData)
                : [];
            $playlistFound = false;
            foreach ($playlistRows as $playlistRow) {
                if (is_array($playlistRow) && (int)($playlistRow['id'] ?? 0) === $playlistId) {
                    $playlistFound = true;
                    break;
                }
            }
            if (!$playlistFound) {
                throw new \RuntimeException('Playlist sa a pa egziste oswa API key la pa ka jwenn li.');
            }

            [$host, $ip] = $this->validateRemoteUrl($url);
            $parts = parse_url($url);
            $extension = strtolower(pathinfo(rawurldecode($parts['path'] ?? ''), PATHINFO_EXTENSION));
            if (!in_array($extension, self::ALLOWED_EXTENSIONS, true)) {
                throw new \RuntimeException('Lyen an dwe fini ak yon ekstansyon odyo sipòte (MP3, M4A, AAC, OGG, OPUS, FLAC, WAV oswa AIFF).');
            }

            $download = $client->request('GET', $url, [
                'resolve' => [$host . ':443' => $ip],
                'headers' => ['Accept' => 'audio/*, application/octet-stream;q=0.9'],
            ]);
            $status = $download->getStatusCode();
            if ($status < 200 || $status >= 300) {
                throw new \RuntimeException('Sèvè lyen an pa bay fichye odyo a (HTTP ' . $status . '). Lyen redireksyon pa aksepte.');
            }

            $headers = $download->getHeaders(false);
            $mime = strtolower(trim(explode(';', $headers['content-type'][0] ?? '')[0]));
            if ($mime !== '' && !str_starts_with($mime, 'audio/') && $mime !== 'application/octet-stream') {
                throw new \RuntimeException('Adrès la pa retounen yon fichye odyo.');
            }
            $length = (int)($headers['content-length'][0] ?? 0);
            if ($length > self::MAX_BYTES) {
                throw new \RuntimeException('Fichye a twò gwo; limit la se 100 MB.');
            }

            $tmpFile = tempnam(sys_get_temp_dir(), 'azuracast-audio-');
            if ($tmpFile === false) {
                throw new \RuntimeException('Pa kapab prepare fichye tanporè a.');
            }
            $out = fopen($tmpFile, 'wb');
            if ($out === false) {
                throw new \RuntimeException('Pa kapab ekri fichye odyo a.');
            }
            $written = 0;
            foreach ($client->stream($download) as $chunk) {
                if ($chunk->isTimeout()) {
                    continue;
                }
                $bytes = $chunk->getContent();
                $written += strlen($bytes);
                if ($written > self::MAX_BYTES) {
                    fclose($out);
                    throw new \RuntimeException('Fichye a depase limit 100 MB.');
                }
                fwrite($out, $bytes);
            }
            fclose($out);
            if ($written === 0) {
                throw new \RuntimeException('Lyen an pa retounen done odyo.');
            }

            $filename = $this->safeFilename($parts['path'] ?? '', $extension);
            $form = new FormDataPart(['file' => DataPart::fromPath($tmpFile, $filename, $mime ?: 'application/octet-stream')]);
            $uploadUrl = $apiBase . '/api/station/' . $stationId . '/files/upload?searchPhrase=' . rawurlencode('playlist:' . $playlistId);
            $upload = $client->request('POST', $uploadUrl, [
                'headers' => ['X-API-Key' => $apiKey, 'Accept' => 'application/json'] + $form->getPreparedHeaders()->toArray(),
                'body' => $form->bodyToIterable(),
            ]);
            $uploadStatus = $upload->getStatusCode();
            $uploadBody = $upload->getContent(false);
            if ($uploadStatus < 200 || $uploadStatus >= 300) {
                throw new \RuntimeException('AzuraCast pa t aksepte fichye a (HTTP ' . $uploadStatus . '). Verifye dwa API key la ak kapasite estasyon an.');
            }

            return $response->withJson([
                'success' => true,
                'message' => 'Fichye a telechaje epi ajoute nan playlist la.',
                'filename' => $filename,
                'bytes' => $written,
                'station_id' => $stationId,
                'playlist_id' => $playlistId,
                'azuracast_response' => json_decode($uploadBody, true),
            ]);
        } catch (Throwable $e) {
            return $response->withStatus(400)->withJson([
                'success' => false,
                'message' => $e instanceof \RuntimeException ? $e->getMessage() : 'Enpòte a echwe. Verifye URL la ak aksè estasyon an.',
            ]);
        } finally {
            if (is_string($tmpFile) && is_file($tmpFile)) {
                @unlink($tmpFile);
            }
        }
    }

    /** @return array{string, string} Hostname and a validated public IPv4/IPv6 address. */
    private function validateRemoteUrl(string $url): array
    {
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower($parts['scheme'] ?? '') !== 'https' || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || (isset($parts['port']) && $parts['port'] !== 443)) {
            throw new \RuntimeException('Sèvi ak yon lyen HTTPS dirèk pou yon fichye odyo; lyen YouTube/stream pa sipòte.');
        }

        $host = strtolower(rtrim($parts['host'], '.'));
        $ips = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : array_values(array_unique(array_merge(
            array_column(dns_get_record($host, DNS_A) ?: [], 'ip'),
            array_column(dns_get_record($host, DNS_AAAA) ?: [], 'ipv6')
        )));
        if ($ips === []) {
            throw new \RuntimeException('Pa kapab jwenn adrès sèvè lyen an.');
        }
        foreach ($ips as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
                throw new \RuntimeException('Adrès sèvè prive oswa rezève pa aksepte.');
            }
        }

        return [$host, $ips[0]];
    }

    private function safeFilename(string $path, string $extension): string
    {
        $name = rawurldecode(basename($path));
        $name = preg_replace('/[^A-Za-z0-9._ -]+/', '-', $name) ?: '';
        $name = trim($name, '. -_');
        if ($name === '' || strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== $extension) {
            $name = 'Audio-' . gmdate('Ymd-His') . '.' . $extension;
        }
        return substr($name, 0, 180);
    }
}
