<?php

declare(strict_types=1);

use App\CallableEventDispatcherInterface;
use App\Event;
use App\Middleware\EnableView;
use Plugin\DirectAudioImport\Controller\ImportAudio;

require_once __DIR__ . '/src/Controller/ImportAudio.php';

return static function (CallableEventDispatcherInterface $dispatcher): void {
    $dispatcher->addListener(Event\BuildView::class, static function (Event\BuildView $event): void {
        $event->getView()->addFolder('direct_audio_import', __DIR__ . '/templates');
    });

    $dispatcher->addListener(Event\BuildRoutes::class, static function (Event\BuildRoutes $event): void {
        $app = $event->getApp();

        $app->get('/direct-audio-import', ImportAudio::class)
            ->setName('direct-audio-import:index')
            ->add(EnableView::class);

        $app->post('/direct-audio-import/import', ImportAudio::class)
            ->setName('direct-audio-import:import');
    });
};
