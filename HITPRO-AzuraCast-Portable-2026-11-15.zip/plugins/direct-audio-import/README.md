# Direct Audio Import for AzuraCast

Adds `/direct-audio-import` to an AzuraCast instance. A user pastes a direct HTTPS audio-file URL, selects an accessible station and playlist, and imports the file using AzuraCast's native media upload pipeline. The upload is assigned to the selected playlist via the upload endpoint's `searchPhrase=playlist:<id>` support.

Supported extensions: MP3, M4A, AAC, OGG/OGA, OPUS, FLAC, WAV and AIFF. Files are capped at 100 MB. This importer accepts direct audio file links only; YouTube pages and streaming URLs are not supported.

## Install (Docker AzuraCast)

1. Copy this folder onto the AzuraCast host, under `/var/azuracast/plugins/direct-audio-import`.
2. Add this to `/var/azuracast/docker-compose.override.yml` (merge it with any existing overrides):

   ```yaml
   services:
     web:
       environment:
         AZURACAST_PLUGIN_MODE: true
       volumes:
         - ./plugins/direct-audio-import:/var/azuracast/www/plugins/direct-audio-import:ro
   ```

3. Restart AzuraCast using its normal Docker workflow.
4. Sign in and open `https://YOUR-AZURACAST-HOST/direct-audio-import`.
5. Create an API key in your AzuraCast account, paste it into the page, and choose a station/playlist. The page keeps the key in the current browser session only.

If `docker-compose.override.yml` already exists, preserve its current entries while adding this plugin mount.

## Security behavior

- Import requests require an AzuraCast API key with access to the selected station and playlist.
- The selected station and playlist are validated before the remote file is fetched.
- Only HTTPS URLs on public DNS/IP addresses are accepted. Redirects, credentials embedded in URLs, private/reserved IPs, non-audio content and oversized files are rejected.
- The API key is not written to server-side storage. Temporary downloaded files are deleted after import.
